'use strict';
const express = require('express');
const fs = require('fs');
const path = require('path');

function readJsonSafe(filePath, fallback) {
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf8'));
  } catch (err) {
    return fallback;
  }
}

function rankFromOpLevel(level) {
  if (level >= 4) return 'owner';
  if (level === 3) return 'admin';
  if (level >= 1) return 'moderator';
  return 'member';
}

async function parseOnlineNames(pm) {
  if (pm.state !== 'online') return [];
  try {
    const resp = await pm.sendCommand('list', { logAsUser: false });
    // Typical: "There are 3 of a max of 20 players online: Foo, Bar, Baz"
    const idx = resp.indexOf(':');
    if (idx === -1) return [];
    return resp.slice(idx + 1).split(',').map((s) => s.trim()).filter(Boolean);
  } catch (err) {
    return [];
  }
}

module.exports = function playerRoutes(config, pm) {
  const router = express.Router();
  const dir = config.server.directory;

  router.get('/players', async (req, res) => {
    try {
      const online = await parseOnlineNames(pm);
      const ops = readJsonSafe(path.join(dir, 'ops.json'), []);
      const whitelist = readJsonSafe(path.join(dir, 'whitelist.json'), []);
      const banned = readJsonSafe(path.join(dir, 'banned-players.json'), []);
      const usercache = readJsonSafe(path.join(dir, 'usercache.json'), []);

      const byName = new Map();
      usercache.forEach((u) => byName.set(u.name, { name: u.name, lastSeen: u.expiresOn || null }));
      whitelist.forEach((u) => { if (!byName.has(u.name)) byName.set(u.name, { name: u.name }); });
      ops.forEach((u) => { if (!byName.has(u.name)) byName.set(u.name, { name: u.name }); });
      online.forEach((name) => { if (!byName.has(name)) byName.set(name, { name }); });

      const bannedNames = new Set(banned.map((b) => b.name));
      const opMap = new Map(ops.map((o) => [o.name, o.level]));
      const whitelistNames = new Set(whitelist.map((w) => w.name));

      const players = Array.from(byName.values()).map((p) => ({
        name: p.name,
        online: online.includes(p.name),
        rank: opMap.has(p.name) ? rankFromOpLevel(opMap.get(p.name)) : 'member',
        whitelisted: whitelistNames.has(p.name),
        banned: bannedNames.has(p.name),
        lastSeen: p.lastSeen || null,
        // Playtime and ping require a plugin (e.g. spark/StatsAPI) or per-player
        // stats-file parsing; not populated here.
        playtimeHours: null,
        ping: null,
      }));

      players.sort((a, b) => (b.online - a.online) || a.name.localeCompare(b.name));
      res.json(players);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  router.post('/players/:name/kick', async (req, res) => {
    try {
      const reason = req.body && req.body.reason ? ' ' + req.body.reason : '';
      await pm.sendCommand(`kick ${req.params.name}${reason}`);
      res.json({ ok: true });
    } catch (err) { res.status(400).json({ error: err.message }); }
  });

  router.post('/players/:name/ban', async (req, res) => {
    try {
      const reason = req.body && req.body.reason ? ' ' + req.body.reason : '';
      await pm.sendCommand(`ban ${req.params.name}${reason}`);
      res.json({ ok: true });
    } catch (err) { res.status(400).json({ error: err.message }); }
  });

  router.post('/players/:name/unban', async (req, res) => {
    try {
      await pm.sendCommand(`pardon ${req.params.name}`);
      res.json({ ok: true });
    } catch (err) { res.status(400).json({ error: err.message }); }
  });

  router.post('/players/:name/op', async (req, res) => {
    try {
      await pm.sendCommand(`op ${req.params.name}`);
      res.json({ ok: true });
    } catch (err) { res.status(400).json({ error: err.message }); }
  });

  router.post('/players/:name/deop', async (req, res) => {
    try {
      await pm.sendCommand(`deop ${req.params.name}`);
      res.json({ ok: true });
    } catch (err) { res.status(400).json({ error: err.message }); }
  });

  router.post('/players/:name/whitelist', async (req, res) => {
    try {
      const add = req.body ? req.body.add !== false : true;
      await pm.sendCommand(`whitelist ${add ? 'add' : 'remove'} ${req.params.name}`);
      res.json({ ok: true });
    } catch (err) { res.status(400).json({ error: err.message }); }
  });

  router.post('/players/:name/message', async (req, res) => {
    try {
      const msg = (req.body && req.body.message || '').trim();
      if (!msg) throw new Error('Empty message');
      await pm.sendCommand(`tell ${req.params.name} ${msg}`);
      res.json({ ok: true });
    } catch (err) { res.status(400).json({ error: err.message }); }
  });

  return router;
};
