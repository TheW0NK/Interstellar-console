'use strict';
const express = require('express');

module.exports = function powerRoutes(pm) {
  const router = express.Router();

  router.get('/status', (req, res) => {
    res.json({ state: pm.state, uptimeMs: pm.getUptimeMs(), pid: pm.getPid() });
  });

  router.post('/power/start', (req, res) => {
    try { pm.start(); res.json({ ok: true }); }
    catch (err) { res.status(400).json({ error: err.message }); }
  });

  router.post('/power/restart', async (req, res) => {
    try { await pm.restart(); res.json({ ok: true }); }
    catch (err) { res.status(400).json({ error: err.message }); }
  });

  router.post('/power/stop', async (req, res) => {
    try { await pm.stop(); res.json({ ok: true }); }
    catch (err) { res.status(400).json({ error: err.message }); }
  });

  router.post('/power/kill', (req, res) => {
    try { pm.kill(); res.json({ ok: true }); }
    catch (err) { res.status(400).json({ error: err.message }); }
  });

  return router;
};
